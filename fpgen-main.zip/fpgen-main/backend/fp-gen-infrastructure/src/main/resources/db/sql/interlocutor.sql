INSERT INTO interlocutor (id, creation_date, modification_date, type, number) VALUES (7, '2024-10-20 07:05:00.110203', '2024-10-20 07:05:00.110203', 'SOCIAL_ENGINEER', null);
INSERT INTO interlocutor (id, creation_date, modification_date, type, number) VALUES (8, '2024-10-20 07:05:07.476976', '2024-10-20 07:05:07.476976', 'HARASSER', null);
INSERT INTO interlocutor (id, creation_date, modification_date, type, number) VALUES (6, '2024-10-13 15:34:04.702642', '2024-10-13 15:34:04.702642', 'GENUINE', 1);
INSERT INTO interlocutor (id, creation_date, modification_date, type, number) VALUES (2, '2025-01-01 00:00:00.000000', '2025-01-01 00:00:00.000000', 'GENUINE', 2);
