package be.unamur.fpgen.notification;

public enum NotificationStatus {
    UNREAD, READ
}
