package be.unamur.fpgen.generation.ongoing_generation;

public enum OngoingGenerationItemStatus {
    WAITING, SUCCESS, FAILURE
}
