package be.unamur.fpgen.dataset;

public enum DatasetFunctionEnum {
    TRAINING, TEST, VALIDATION
}
