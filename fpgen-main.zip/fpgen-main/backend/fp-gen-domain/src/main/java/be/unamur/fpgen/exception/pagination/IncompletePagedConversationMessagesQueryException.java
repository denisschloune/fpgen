package be.unamur.fpgen.exception.pagination;

public class IncompletePagedConversationMessagesQueryException extends RuntimeException {
    public IncompletePagedConversationMessagesQueryException(String message) {
    }
}
