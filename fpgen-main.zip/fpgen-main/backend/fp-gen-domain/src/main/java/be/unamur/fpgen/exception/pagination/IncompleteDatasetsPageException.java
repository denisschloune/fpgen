package be.unamur.fpgen.exception.pagination;

public class IncompleteDatasetsPageException extends RuntimeException {
    public IncompleteDatasetsPageException(String s) {
    }
}
