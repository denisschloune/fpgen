package be.unamur.fpgen.generation;

public enum GenerationTypeEnum {
    INSTANT_MESSAGE, CONVERSATION
}
