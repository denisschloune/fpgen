package be.unamur.fpgen.message;

public enum MessageTopicEnum {
    SPORT,
    WORK,
    POLITICS,
    SCIENCE,
    TECHNOLOGY,
    ART,
    MUSIC,
    MOVIES,
    GAMES,
    LITERATURE,
    PHILOSOPHY,
    RELIGION,
    HISTORY,
    GEOGRAPHY,
    ECONOMY,
    SOCIETY,
    HEALTH,
    EDUCATION,
    ENVIRONMENT,
    ROMANCE,
    OTHER
}
