package be.unamur.fpgen.project;

public enum ProjectTypeEnum {
    INSTANT_MESSAGE, CONVERSATION
}
