package be.unamur.fpgen.exception.pagination;

public class IncompleteAuthorsPageException extends RuntimeException {
    public IncompleteAuthorsPageException(String s) {
    }
}
