package be.unamur.fpgen.prompt;

public enum PromptStatusEnum {
    VALIDATED, REFUSED, DEPRECATED, WAITING_ANALYSE, ONGOING_ANALYSE
}
