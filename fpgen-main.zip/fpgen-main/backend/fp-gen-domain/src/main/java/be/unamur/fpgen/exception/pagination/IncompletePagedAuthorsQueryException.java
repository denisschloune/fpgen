package be.unamur.fpgen.exception.pagination;

public class IncompletePagedAuthorsQueryException extends RuntimeException {
    public IncompletePagedAuthorsQueryException(String s) {
    }
}
