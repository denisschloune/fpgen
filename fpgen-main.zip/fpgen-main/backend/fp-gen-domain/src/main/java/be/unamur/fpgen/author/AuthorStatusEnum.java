package be.unamur.fpgen.author;

public enum AuthorStatusEnum {
    WAITING_VERIFICATION, VERIFIED, BANISHED, SUSPENDED
}
