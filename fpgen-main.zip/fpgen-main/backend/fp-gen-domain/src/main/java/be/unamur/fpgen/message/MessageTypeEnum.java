package be.unamur.fpgen.message;

public enum MessageTypeEnum {
    SOCIAL_ENGINEERING,
    HARASSMENT,
    GENUINE
}
