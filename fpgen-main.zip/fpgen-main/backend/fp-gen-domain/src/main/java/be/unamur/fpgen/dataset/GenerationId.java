package be.unamur.fpgen.dataset;

public interface GenerationId {
    String generateGenerationId();
}
