package be.unamur.fpgen.dataset;

public enum DatasetTypeEnum {
    INSTANT_MESSAGE, CONVERSATION
}
