package be.unamur.fpgen.exception.pagination;

public class IncompleteConversationMessagesPageException extends RuntimeException {
    public IncompleteConversationMessagesPageException(String s) {
    }
}
