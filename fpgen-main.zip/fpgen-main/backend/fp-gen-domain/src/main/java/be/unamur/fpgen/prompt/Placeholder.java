package be.unamur.fpgen.prompt;

public enum Placeholder {
    NUMBER, TOPIC, MIN_INTERACTION, MAX_INTERACTION
}
