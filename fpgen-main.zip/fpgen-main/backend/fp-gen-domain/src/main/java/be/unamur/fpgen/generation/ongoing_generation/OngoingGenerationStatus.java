package be.unamur.fpgen.generation.ongoing_generation;

public enum OngoingGenerationStatus {
    WAITING, ONGOING, SUCCESSFUL, PARTIALLY_FAILED, FAILED
}
