package be.unamur.fpgen.interlocutor;

public enum InterlocutorTypeEnum {
    GENUINE,
    SOCIAL_ENGINEER,
    HARASSER
}
